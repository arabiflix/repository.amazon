# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re, base64

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['gr']
        self.domains = ['tainies4k.online']
        self.base_link = 'https://tenies-online.gr/'
        self.search_link = '?s=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(
                aliases),year)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = self.__search([localtvshowtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and tvshowtitle != localtvshowtitle: url = self.__search(
                [tvshowtitle] + source_utils.aliases_to_array(aliases), year)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return

            url = [{'url': url, 'season': season, 'episode': episode}]
            return url
        except BaseException:
            return

    def __search(self, titles, year):
        try:
            tit = [i.split(':')[0] for i in titles]
            query = [self.search_link % (urllib.quote_plus(cleantitle.getsearch(i))) for i in tit]
            query = [urlparse.urljoin(self.base_link, i) for i in query]
            t = [cleantitle.get(i) for i in set(titles) if i]

            for u in query:
                try:
                    r = client.request(u)
                    r = client.parseDOM(r, 'div', attrs={'class': 'result-item'})
                    r = [(client.parseDOM(i, 'a', ret='href')[0],
                          client.parseDOM(i, 'img', ret='alt')[0],
                          client.parseDOM(i, 'span', attrs={'class': 'year'})[0]) for i in r if i]
                    r = [(i[0], i[1], i[2]) for i in r if i[2]]
                    r = [(i[0]) for i in r if year == i[2]]
                    url = r[0]

                    return url
                except BaseException:
                    pass

            return
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources

            if type(url) is list:
                url = url[0]
                query, season, episode = url['url'], url['season'], url['episode']
                r = client.request(query)
                r = client.parseDOM(r, 'ul', attrs={'class': 'episodios'})[0]
                epis = client.parseDOM(r, 'li', attrs={'class': r'mark-\d+'})
                epis = [(client.parseDOM(i, 'a', ret='href')[0],
                         client.parseDOM(i, 'div', {'class': 'numerando'})[0]) for i in epis if epis]
                pattern = '{} - {}'.format(int(season), int(episode))
                query = [i[0] for i in epis if pattern == i[1]][0]

                # html = client.request(epis)
                # print html
                # links = dom_parser2.parse_dom(html, 'a', req='href')
                # links = [(i.attrs['href'], i.content) for i in links if '%02d' % int(episode) in i.content]
                # links = [i[0] for i in links]
            else:
                query = url

            r = client.request(query)
            links = client.parseDOM(r, 'tr', {'id': r'link-\d+'})
            links = [(client.parseDOM(i, 'a', ret='href')[0],
                      client.parseDOM(i, 'img', ret='src')[0],
                      client.parseDOM(i, 'strong', {'class': 'quality'})[0],
                      client.parseDOM(i, 'td')[-3]) for i in links if links]

            for url, domain, quality, info in links:
                try:
                    quality = quality.encode('utf-8')
                    info = info.encode('utf-8')
                    host = domain.split('=')[-1].encode('utf-8')
                    if 'Μεταγλωτισμεν' in info:
                        info = 'GREEK'
                    elif 'Ελληνικο' in info:
                        info = 'SUBS'
                    elif 'Χωρ' in info:
                        info = 'No SUBS'
                    else:
                        info = '[N/A]'
                    if 'Υψηλ' in quality:
                        quality = '1080p'
                    elif 'Μεσαία' in quality:
                        quality = '720p'
                    else:
                        quality = 'SD'

                    # if any(x in url for x in ['.online', 'xrysoi.se', 'filmer', '.bp', '.blogger', 'youtu']):
                    #     continue

                    # valid, host = source_utils.is_host_valid(host, hostDict)
                    # if not valid:
                    #     continue
                    lang = 'gr'
                    if 'openload' in host.lower() or 'oload' in host.lower():
                        r = client.request(url)
                        try:
                            sub = client.parseDOM(r, 'track', ret='src', attrs={'srclang': 'el'})[0]
                            sources.append({'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                            'sub': sub, 'direct': False, 'debridonly': False})
                        except BaseException:
                            sources.append(
                                {'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                 'direct': False, 'debridonly': False})

                    else:
                        sources.append({'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                        'direct':False,'debridonly': False})
                except BaseException:
                    pass
            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        if '/links/' in url:
            url = client.request(url)
            url = client.parseDOM(url, 'a', {'id': 'link'}, ret='href')[0]
        return url
