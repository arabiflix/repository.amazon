# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2 as dom
from resources.lib.modules import trakt
#from resources.lib.modules import cfscrape


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['gr']
        self.domains = ['tainiomania.ucoz.com', 'tainio-mania.com']
        self.base_link = 'http://tainio-mania.co/'
        self.search_link = '?story={}&titleonly=3&do=search&subaction=search'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year, 'movie')
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(
                aliases),year, 'movie')
            if not url: url = self.__search(trakt.getMovieTranslation(imdb, 'el'), year, 'movie')
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = self.__search([localtvshowtitle] + source_utils.aliases_to_array(aliases), year, 'show')
            if not url and tvshowtitle != localtvshowtitle: url = self.__search(
                [tvshowtitle] + source_utils.aliases_to_array(aliases), year, 'show')
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = [{'url': url, 'season': season, 'episode': episode}]
            return url
        except BaseException:
            return

    def __search(self, titles, year, content):
        try:
            query = [self.search_link.format(urllib.quote_plus(cleantitle.getsearch(i) + ' ' + year)) for i in titles]

            query = [urlparse.urljoin(self.base_link, i) for i in query]

            t = [cleantitle.get(i) for i in set(titles) if i]

            for u in query:
                try:
                    headers = {'User-Agent': client.agent(),
                               'Referer': self.base_link}
                    #scraper = cfscrape.create_scraper()
                    #r = scraper.get(u, headers=headers, verify=False).content
                    r = client.request(u)
                    r = client.parseDOM(r, 'div', {'class': 'v_pict'})
                    for i in r:
                        data = dom.parse_dom(i, 'a', req='href')[0]
                        title = client.parseDOM(i, 'img', ret='alt')[0]
                        y = re.findall('(\d{4})', title, re.DOTALL)[0]
                        if 'seir' in content:
                            if any(x in cleantitle.get(title) for x in t)and year == y:
                                return data.attrs['href']
                        else:
                            if any(x in cleantitle.get(title) for x in t) and year == y:
                                return data.attrs['href']
                except BaseException:
                    pass
            return
        except BaseException:
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources
            # scraper = cfscrape.create_scraper()
            headers = {'User-Agent': client.agent(),
                       'Referer': self.base_link}
            if type(url) is list:
                url = url[0]
                #http://tainio-mania.co/php/ldm57.php?id=2544
                query, season, episode = url['url'], url['season'], url['episode']
                # r = scraper.get(query, headers=headers).content
                # text_url = 'http://tainio-mania.co/php/ldm57.php?id={0}'.format(query.split('-')[-1])
                r = client.request(query, referer=query).replace('\\', '')
                # txt = re.findall('''Playerjs.+?file:['"](.+?)['"]\}''', r, re.DOTALL)[0]
                txt = client.parseDOM(r, 'span', {'class': "pltx"})[0]
                # data = client.request(urlparse.urljoin(self.base_link, txt), headers=headers)
                sep = '%dx%02d' % (int(season), int(episode))
                url = re.findall('file":"(.+?.mp4)"', txt, re.DOTALL)
                url = [i for i in url if sep in str(i)][0]
                url += '|User-Agent=%s&Referer=%s' % (urllib.quote_plus(client.agent()), urllib.quote_plus(query))
                quality = '720p'
                lang, info = 'gr', 'SUB'

                sources.append({'source': 'DL', 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                'direct': True, 'debridonly': False})

            else:
                query = url
                # text_url = 'http://tainio-mania.co/php/ldm57.php?id={0}'.format(query.split('-')[-1])
                r = client.request(query, headers)
                pdata = re.findall(r'''mod:\s*'(\w+)',\s*news_id:\s*'(.+?)'\}''', r, re.DOTALL)[0]
                pdata = 'mod={}&news_id={}'.format(pdata[0], pdata[1])
                headers['Referer'] = query
                plink = urlparse.urljoin(self.base_link, '/engine/ajax/controller.php')
                post = client.request(plink, post=pdata, headers=headers).replace('\\', '')
                txt = re.findall('''Playerjs.+?file:['"](.+?)['"]''', post, re.DOTALL)[0]
                # txt = client.parseDOM(r, 'span', {'class': "pltx"})[0]
                url = urlparse.urljoin(self.base_link, txt)
                url += '|User-Agent=%s&Referer=%s' % (urllib.quote_plus(client.agent()), urllib.quote_plus(query))
                sources.append({'source': 'DL', 'quality': '720p', 'language': 'GR', 'url': url,
                                'info': 'SUB', 'direct': True, 'debridonly': False})

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url