# plugin.video.theamazon
theamazon add-on

--- For testing and learning purposes - Not for public use (use at your own risk) ---

--- NOTE: The version on this git repo does not come with API keys                ---